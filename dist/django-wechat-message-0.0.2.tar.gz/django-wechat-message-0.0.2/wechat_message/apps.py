from django.apps import AppConfig


class WechatMessageConfig(AppConfig):
    name = 'wechat_message'
